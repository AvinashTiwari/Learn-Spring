package learn.avinash.contract.testing.springcontracttestingcreditcardservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringContractTestingCreditcardserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringContractTestingCreditcardserviceApplication.class, args);
	}

}

